package com.cg.traineemgt.controller;


import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.traineemgt.dto.QueryMaster;
import com.cg.traineemgt.service.IQueryMasterService;
import com.cg.traineemgt.service.QueryMasterServiceImpl;

@Controller
public class QueryMasterController {
	@Autowired
	IQueryMasterService service;
	
	@RequestMapping(value="ansqry")
	public String answerQuery(@RequestParam("qid") int qid,
			Model model)
	{
		QueryMaster query=service.fetch(qid);
		if(query!= null)
		{
			model.addAttribute("query", query);
			
			return "updateSolution";
		}
		else
		{
			model.addAttribute("errormsg", "Mobile id is invalid");
			return "failure";
		}
		
		
	}
	
	@RequestMapping(value="updatesuccess")
	public String update(@ModelAttribute("uu") QueryMaster query)
	{
		service.updateSolution(query);
		return "updatesuccess";
	}
	

	
	

}
