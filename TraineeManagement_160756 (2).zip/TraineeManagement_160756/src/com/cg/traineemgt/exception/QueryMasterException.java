package com.cg.traineemgt.exception;



public class QueryMasterException extends RuntimeException{
   private String exceptionMsg;
   
   public QueryMasterException(String exceptionMsg) {
      this.exceptionMsg = exceptionMsg;
   }
   public String getExceptionMsg(){
      return this.exceptionMsg;
   }
   public void setExceptionMsg(String exceptionMsg) {
      this.exceptionMsg = exceptionMsg;
   }
}