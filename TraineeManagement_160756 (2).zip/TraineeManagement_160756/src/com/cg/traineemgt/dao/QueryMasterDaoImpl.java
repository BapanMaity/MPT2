package com.cg.traineemgt.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;


import com.cg.traineemgt.dto.QueryMaster;

@Repository
public class QueryMasterDaoImpl implements IQueryMasterDao {

	
	@PersistenceContext
	EntityManager em;
	@Override
	public int updateSolution(QueryMaster query) {
		em.merge(query);
		//em.persist(query);
		return query.getQid();

	}
	@Override
	public QueryMaster fetch(int qid) {
		
		QueryMaster qry = em.find(QueryMaster.class, qid);
		return qry;
	}

}
