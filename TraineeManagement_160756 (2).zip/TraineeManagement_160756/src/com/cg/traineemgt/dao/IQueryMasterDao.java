package com.cg.traineemgt.dao;


import com.cg.traineemgt.dto.QueryMaster;

public interface IQueryMasterDao {
	public int updateSolution(QueryMaster query);
	public QueryMaster fetch(int qid);
	

}
