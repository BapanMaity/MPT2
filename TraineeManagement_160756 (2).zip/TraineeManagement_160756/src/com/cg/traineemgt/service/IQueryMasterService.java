package com.cg.traineemgt.service;

import com.cg.traineemgt.dto.QueryMaster;



public interface IQueryMasterService {
	
	public int updateSolution(QueryMaster query);
	public QueryMaster fetch(int qid);

}
